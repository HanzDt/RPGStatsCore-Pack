RPGStatsCore Custom Ore Equipment Patch - Minecraft 26.2

Added:
- Silver, Cobalt, Mythril, Adamantite
- Sword, Spear, Axe, Pickaxe, Shovel, Hoe
- Helmet, Chestplate, Leggings, Boots
- 60 custom equipment recipes
- Per-craft RPG random affixes
- Custom item_model component for Java 26.2
- Geyser v2 custom-item mappings and a starter Bedrock resource pack

Default progression:
Silver Lv35
Cobalt Lv45
Mythril Lv80
Adamantite Lv95

The custom equipment uses vanilla carrier items internally and a PDC id to distinguish
the RPG item. The resource pack changes its visual model.

Important:
- The Java resource pack must be applied to Java clients.
- For Bedrock/Geyser, enable Geyser custom content and install the supplied mapping JSON
  in Geyser's custom_mappings folder plus the supplied Bedrock pack in Geyser's packs folder.
- The supplied Bedrock pack currently covers inventory/held item icons. Custom worn armor
  layer/attachable textures are not included because the supplied source archive only
  contained 16x16 inventory armor icons, not humanoid armor-layer textures.
- Custom ore blocks/placed ore behavior are not added by this patch; this patch focuses
  on ingots and equipment as requested.

Stats can be adjusted later in WeaponService.registerCustomEquipment().

CUSTOM ORE GENERATOR
- Silver: Iron-like frequency/vein size.
- Cobalt: Diamond-like frequency/vein size.
- Mythril: rarer than Diamond, single block per successful spawn.
- Adamantite: Emerald-class rarity, single block per successful spawn.
- Vanilla ore generation is untouched.
- Custom ore generation is enabled only in the new world named `newworld`.
